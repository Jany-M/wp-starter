<?php 

$ALLOWED_SITES = array (
		'flickr.com',
		'staticflickr.com',
		'picasa.com',
		'img.youtube.com',
		'upload.wikimedia.org',
		'photobucket.com',
		'imgur.com',
		'imageshack.us',
		'tinypic.com',
		'amazonaws.com',
		'pinterest.com',
		'google.com',
		'maps.google.com',
	);

?>